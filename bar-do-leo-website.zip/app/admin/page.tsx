"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Plus, Edit, Trash2, Save, X, Upload, ArrowLeft } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

interface Bebida {
  id: string
  nome: string
  preco: number
  imagem: string
  categoria?: string
  precoOriginal?: number
  desconto?: number
  observacao?: string
}

export default function AdminPage() {
  const [bebidas, setBebidas] = useState<Bebida[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingBebida, setEditingBebida] = useState<Bebida | null>(null)
  const [formData, setFormData] = useState({
    nome: "",
    preco: "",
    precoOriginal: "",
    imagem: "",
    categoria: "",
    observacao: "",
  })

  useEffect(() => {
    const bebidasSalvas = localStorage.getItem("bebidas")
    if (bebidasSalvas) {
      setBebidas(JSON.parse(bebidasSalvas))
    }
  }, [])

  const salvarBebidas = (novasBebidas: Bebida[]) => {
    setBebidas(novasBebidas)
    localStorage.setItem("bebidas", JSON.stringify(novasBebidas))
  }

  const calcularDesconto = (preco: number, precoOriginal: number) => {
    return Math.round(((precoOriginal - preco) / precoOriginal) * 100)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.nome || !formData.preco) {
      alert("Nome e preço são obrigatórios!")
      return
    }

    const preco = Number.parseFloat(formData.preco)
    const precoOriginal = formData.precoOriginal ? Number.parseFloat(formData.precoOriginal) : undefined
    const desconto = precoOriginal && precoOriginal > preco ? calcularDesconto(preco, precoOriginal) : undefined

    const novaBebida: Bebida = {
      id: editingBebida ? editingBebida.id : Date.now().toString(),
      nome: formData.nome,
      preco,
      precoOriginal,
      desconto,
      imagem: formData.imagem || "/placeholder.svg?height=200&width=200",
      categoria: formData.categoria || undefined,
      observacao: formData.observacao || undefined,
    }

    if (editingBebida) {
      const bebidasAtualizadas = bebidas.map((b) => (b.id === editingBebida.id ? novaBebida : b))
      salvarBebidas(bebidasAtualizadas)
    } else {
      salvarBebidas([...bebidas, novaBebida])
    }

    resetForm()
  }

  const resetForm = () => {
    setFormData({ nome: "", preco: "", precoOriginal: "", imagem: "", categoria: "", observacao: "" })
    setEditingBebida(null)
    setIsDialogOpen(false)
  }

  const handleEdit = (bebida: Bebida) => {
    setEditingBebida(bebida)
    setFormData({
      nome: bebida.nome,
      preco: bebida.preco.toString(),
      precoOriginal: bebida.precoOriginal?.toString() || "",
      imagem: bebida.imagem,
      categoria: bebida.categoria || "",
      observacao: bebida.observacao || "",
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    if (confirm("Tem certeza que deseja excluir esta bebida?")) {
      const bebidasFiltradas = bebidas.filter((b) => b.id !== id)
      salvarBebidas(bebidasFiltradas)
    }
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setFormData({ ...formData, imagem: e.target?.result as string })
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button size="icon" variant="outline">
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              </Link>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center">
                  <span className="text-lg">🍺</span>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">Bar do Léo - Admin</h1>
                  <p className="text-gray-600">Painel de Administração</p>
                </div>
              </div>
            </div>
            <Link href="/">
              <Button variant="outline">Ver Site</Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total de Bebidas</p>
                  <p className="text-3xl font-bold text-red-600">{bebidas.length}</p>
                </div>
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                  <span className="text-2xl">🍺</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Valor Médio</p>
                  <p className="text-3xl font-bold text-green-600">
                    R${" "}
                    {bebidas.length > 0
                      ? (bebidas.reduce((acc, b) => acc + b.preco, 0) / bebidas.length).toFixed(2)
                      : "0,00"}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-2xl">💰</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Em Promoção</p>
                  <p className="text-3xl font-bold text-orange-600">{bebidas.filter((b) => b.precoOriginal).length}</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <span className="text-2xl">🏷️</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Products Management */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-2xl">Gerenciar Bebidas</CardTitle>
              <Button onClick={() => setIsDialogOpen(true)} className="bg-red-600 hover:bg-red-700">
                <Plus className="w-4 h-4 mr-2" />
                Nova Bebida
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {bebidas.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg">Nenhuma bebida cadastrada ainda.</p>
                <p className="text-gray-400">Clique em "Nova Bebida" para começar.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Imagem</TableHead>
                      <TableHead>Nome</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Preço</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {bebidas.map((bebida) => (
                      <TableRow key={bebida.id}>
                        <TableCell>
                          <div className="w-12 h-12 relative">
                            <Image
                              src={bebida.imagem || "/placeholder.svg"}
                              alt={bebida.nome}
                              fill
                              className="object-cover rounded"
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{bebida.nome}</p>
                            {bebida.observacao && <p className="text-xs text-gray-500">{bebida.observacao}</p>}
                          </div>
                        </TableCell>
                        <TableCell>
                          {bebida.categoria ? (
                            <Badge variant="secondary">{bebida.categoria}</Badge>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-semibold text-green-600">R$ {bebida.preco.toFixed(2)}</p>
                            {bebida.precoOriginal && (
                              <p className="text-sm text-gray-500 line-through">R$ {bebida.precoOriginal.toFixed(2)}</p>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          {bebida.precoOriginal && <Badge className="bg-red-500">-{bebida.desconto}%</Badge>}
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm" onClick={() => handleEdit(bebida)}>
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDelete(bebida.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingBebida ? "Editar Bebida" : "Nova Bebida"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="nome">Nome da Bebida *</Label>
                  <Input
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    placeholder="Ex: Beats GT 269ml - LATA"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="categoria">Categoria</Label>
                  <Input
                    id="categoria"
                    value={formData.categoria}
                    onChange={(e) => setFormData({ ...formData, categoria: e.target.value })}
                    placeholder="Ex: Energéticos, Destilados"
                  />
                </div>

                <div>
                  <Label htmlFor="preco">Preço Atual (R$) *</Label>
                  <Input
                    id="preco"
                    type="number"
                    step="0.01"
                    value={formData.preco}
                    onChange={(e) => setFormData({ ...formData, preco: e.target.value })}
                    placeholder="Ex: 6.00"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="precoOriginal">Preço Original (R$) - Para Promoção</Label>
                  <Input
                    id="precoOriginal"
                    type="number"
                    step="0.01"
                    value={formData.precoOriginal}
                    onChange={(e) => setFormData({ ...formData, precoOriginal: e.target.value })}
                    placeholder="Ex: 7.00"
                  />
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="observacao">Observação</Label>
                  <Input
                    id="observacao"
                    value={formData.observacao}
                    onChange={(e) => setFormData({ ...formData, observacao: e.target.value })}
                    placeholder="Ex: PAGAMENTO PIX OU ESPÉCIE, CASCOS"
                  />
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="imagem">Imagem</Label>
                  <div className="space-y-2">
                    <Input
                      id="imagem"
                      value={formData.imagem}
                      onChange={(e) => setFormData({ ...formData, imagem: e.target.value })}
                      placeholder="URL da imagem ou faça upload"
                    />
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-500">ou</span>
                      <label className="cursor-pointer">
                        <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                        <Button type="button" variant="outline" size="sm" asChild>
                          <span>
                            <Upload className="w-4 h-4 mr-2" />
                            Upload
                          </span>
                        </Button>
                      </label>
                    </div>
                  </div>
                  {formData.imagem && (
                    <div className="mt-2">
                      <div className="w-20 h-20 relative border rounded">
                        <Image
                          src={formData.imagem || "/placeholder.svg"}
                          alt="Preview"
                          fill
                          className="object-cover rounded"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={resetForm}>
                  <X className="w-4 h-4 mr-2" />
                  Cancelar
                </Button>
                <Button type="submit" className="bg-red-600 hover:bg-red-700">
                  <Save className="w-4 h-4 mr-2" />
                  {editingBebida ? "Atualizar" : "Salvar"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
