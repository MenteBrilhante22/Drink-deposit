import { Users, Award, Clock, MapPin, Phone, Mail } from "lucide-react"
import Image from "next/image"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white">
      {/* Header */}
      <header className="bg-slate-900 text-white shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold text-amber-400">🍺 Bar do Léo</div>
            <nav className="hidden md:flex items-center space-x-6">
              <a href="/" className="hover:text-amber-400 transition-colors">
                Início
              </a>
              <a href="/produtos" className="hover:text-amber-400 transition-colors">
                Produtos
              </a>
              <a href="/sobre" className="text-amber-400">
                Sobre
              </a>
              <a href="/contato" className="hover:text-amber-400 transition-colors">
                Contato
              </a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-slate-900 to-slate-800 text-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                Conheça a História do <span className="text-amber-400">Bar do Léo</span>
              </h1>
              <p className="text-xl text-gray-300 mb-8">
                Há mais de 10 anos servindo a comunidade com as melhores bebidas, preços justos e atendimento de
                qualidade.
              </p>
              <Button size="lg" className="bg-amber-500 hover:bg-amber-600 text-black font-semibold">
                <Phone className="w-5 h-5 mr-2" />
                Entre em Contato
              </Button>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=400&width=500"
                alt="Fachada do Bar do Léo"
                width={500}
                height={400}
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Nossa História */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12 text-slate-800">Nossa História</h2>
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <Image
                  src="/placeholder.svg?height=300&width=400"
                  alt="Léo, proprietário do Bar do Léo"
                  width={400}
                  height={300}
                  className="rounded-lg shadow-lg"
                />
              </div>
              <div>
                <p className="text-lg text-gray-700 mb-6">
                  O Bar do Léo nasceu em 2014 do sonho de Leonardo Silva, um apaixonado por bebidas e pelo atendimento
                  ao cliente. O que começou como um pequeno depósito de bebidas no bairro, hoje é referência na região.
                </p>
                <p className="text-lg text-gray-700 mb-6">
                  Nossa missão sempre foi oferecer produtos de qualidade com preços justos, mantendo um relacionamento
                  próximo e de confiança com nossos clientes.
                </p>
                <p className="text-lg text-gray-700">
                  Ao longo dos anos, expandimos nosso catálogo e melhoramos nossos serviços, mas nunca perdemos o foco
                  no que realmente importa: satisfazer nossos clientes.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Nossos Valores */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-slate-800">Nossos Valores</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mx-auto w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mb-4">
                  <Award className="w-8 h-8 text-amber-600" />
                </div>
                <CardTitle className="text-xl">Qualidade</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Selecionamos cuidadosamente todos os produtos que oferecemos, garantindo sempre a melhor qualidade
                  para nossos clientes.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                  <Users className="w-8 h-8 text-green-600" />
                </div>
                <CardTitle className="text-xl">Atendimento</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Nosso time está sempre pronto para ajudar, oferecendo um atendimento personalizado e próximo a cada
                  cliente.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <Clock className="w-8 h-8 text-blue-600" />
                </div>
                <CardTitle className="text-xl">Agilidade</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Entendemos que seu tempo é valioso. Por isso, trabalhamos para oferecer entregas rápidas e atendimento
                  eficiente.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Números */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-slate-800">Bar do Léo em Números</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-amber-600 mb-2">10+</div>
              <p className="text-gray-600">Anos de Experiência</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-amber-600 mb-2">5000+</div>
              <p className="text-gray-600">Clientes Satisfeitos</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-amber-600 mb-2">150+</div>
              <p className="text-gray-600">Produtos Diferentes</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-amber-600 mb-2">24h</div>
              <p className="text-gray-600">Entrega Rápida</p>
            </div>
          </div>
        </div>
      </section>

      {/* Localização */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-slate-800">Nossa Localização</h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="bg-white p-8 rounded-lg shadow-lg">
                <h3 className="text-2xl font-bold mb-6 text-slate-800">Venha nos Visitar!</h3>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <MapPin className="w-5 h-5 text-amber-600 mr-3" />
                    <div>
                      <p className="font-semibold">Endereço</p>
                      <p className="text-gray-600">Rua das Bebidas, 123 - Centro</p>
                      <p className="text-gray-600">São Paulo/SP - CEP: 01234-567</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Phone className="w-5 h-5 text-amber-600 mr-3" />
                    <div>
                      <p className="font-semibold">Telefone</p>
                      <p className="text-gray-600">(11) 99999-9999</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Mail className="w-5 h-5 text-amber-600 mr-3" />
                    <div>
                      <p className="font-semibold">E-mail</p>
                      <p className="text-gray-600">contato@bardoleo.com.br</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Clock className="w-5 h-5 text-amber-600 mr-3" />
                    <div>
                      <p className="font-semibold">Horário de Funcionamento</p>
                      <p className="text-gray-600">Segunda a Sábado: 8h às 22h</p>
                      <p className="text-gray-600">Domingo: 8h às 18h</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className="bg-gray-300 rounded-lg h-96 flex items-center justify-center">
                <p className="text-gray-600">Mapa do Google Maps aqui</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-amber-600 to-amber-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Pronto para fazer seu pedido?</h2>
          <p className="text-xl mb-8">
            Entre em contato conosco e descubra por que somos a escolha certa para suas bebidas!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-amber-600">
              <Phone className="w-5 h-5 mr-2" />
              Ligar Agora
            </Button>
            <Button size="lg" className="bg-green-600 hover:bg-green-700">
              <Phone className="w-5 h-5 mr-2" />
              WhatsApp
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold text-amber-400 mb-4">🍺 Bar do Léo</h3>
              <p className="text-gray-300">Seu depósito de bebidas de confiança há mais de 10 anos.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Links Rápidos</h4>
              <ul className="space-y-2 text-gray-300">
                <li>
                  <a href="/" className="hover:text-amber-400">
                    Início
                  </a>
                </li>
                <li>
                  <a href="/produtos" className="hover:text-amber-400">
                    Produtos
                  </a>
                </li>
                <li>
                  <a href="/sobre" className="hover:text-amber-400">
                    Sobre
                  </a>
                </li>
                <li>
                  <a href="/contato" className="hover:text-amber-400">
                    Contato
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Categorias</h4>
              <ul className="space-y-2 text-gray-300">
                <li>
                  <a href="/cervejas" className="hover:text-amber-400">
                    Cervejas
                  </a>
                </li>
                <li>
                  <a href="/destilados" className="hover:text-amber-400">
                    Destilados
                  </a>
                </li>
                <li>
                  <a href="/vinhos" className="hover:text-amber-400">
                    Vinhos
                  </a>
                </li>
                <li>
                  <a href="/refrigerantes" className="hover:text-amber-400">
                    Refrigerantes
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contato</h4>
              <div className="space-y-2 text-gray-300">
                <p>📞 (11) 99999-9999</p>
                <p>📧 contato@bardoleo.com.br</p>
                <p>📍 Rua das Bebidas, 123</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Bar do Léo. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
