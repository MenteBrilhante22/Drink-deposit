"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Clock, MapPin, Star } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface Bebida {
  id: string
  nome: string
  preco: number
  imagem: string
  categoria?: string
  precoOriginal?: number
  desconto?: number
  observacao?: string
  descricao?: string
}

export default function MenuPage() {
  const [bebidas, setBebidas] = useState<Bebida[]>([])

  useEffect(() => {
    const bebidasSalvas = localStorage.getItem("bebidas")
    if (bebidasSalvas) {
      setBebidas(JSON.parse(bebidasSalvas))
    } else {
      // Menu padrão com mais produtos
      const menuPadrao = [
        // Cervejas
        {
          id: "1",
          nome: "Cerveja Skol Lata 350ml",
          preco: 3.5,
          precoOriginal: 4.0,
          desconto: 13,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Cervejas",
          descricao: "Cerveja lager refrescante, perfeita para o dia a dia",
        },
        {
          id: "2",
          nome: "Cerveja Brahma Lata 350ml",
          preco: 3.5,
          precoOriginal: 4.0,
          desconto: 13,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Cervejas",
          descricao: "Cerveja brasileira tradicional com sabor marcante",
        },
        {
          id: "3",
          nome: "Cerveja Heineken Long Neck 330ml",
          preco: 5.9,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Cervejas",
          descricao: "Cerveja premium holandesa com sabor único",
        },
        {
          id: "4",
          nome: "Cerveja Corona Extra 355ml",
          preco: 6.5,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Cervejas",
          descricao: "Cerveja mexicana leve e refrescante",
        },

        // Destilados
        {
          id: "5",
          nome: "Whisky Red Label 1L",
          preco: 89.9,
          precoOriginal: 99.9,
          desconto: 10,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Destilados",
          descricao: "Whisky escocês premium com blend suave",
          observacao: "PAGAMENTO PIX OU ESPÉCIE",
        },
        {
          id: "6",
          nome: "Vodka Smirnoff 1L",
          preco: 45.9,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Destilados",
          descricao: "Vodka premium russa com pureza excepcional",
        },
        {
          id: "7",
          nome: "Cachaça 51 1L",
          preco: 25.9,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Destilados",
          descricao: "Cachaça brasileira tradicional",
        },

        // Refrigerantes
        {
          id: "8",
          nome: "Coca-Cola 2L",
          preco: 7.5,
          precoOriginal: 8.5,
          desconto: 12,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Refrigerantes",
          descricao: "Refrigerante de cola original",
        },
        {
          id: "9",
          nome: "Guaraná Antarctica 2L",
          preco: 6.9,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Refrigerantes",
          descricao: "Refrigerante de guaraná brasileiro",
        },
        {
          id: "10",
          nome: "Fanta Laranja 2L",
          preco: 6.5,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Refrigerantes",
          descricao: "Refrigerante sabor laranja",
        },

        // Energéticos
        {
          id: "11",
          nome: "Red Bull 250ml",
          preco: 8.9,
          precoOriginal: 9.9,
          desconto: 10,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Energéticos",
          descricao: "Energético premium com taurina",
        },
        {
          id: "12",
          nome: "Monster Energy 473ml",
          preco: 12.9,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Energéticos",
          descricao: "Energético com sabor intenso",
        },

        // Vinhos
        {
          id: "13",
          nome: "Vinho Tinto Seco 750ml",
          preco: 25.9,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Vinhos",
          descricao: "Vinho tinto nacional seco",
        },
        {
          id: "14",
          nome: "Vinho Branco Suave 750ml",
          preco: 22.9,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Vinhos",
          descricao: "Vinho branco suave e refrescante",
        },

        // Águas
        {
          id: "15",
          nome: "Água Mineral Crystal 1,5L",
          preco: 2.5,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Águas",
          descricao: "Água mineral natural",
        },
        {
          id: "16",
          nome: "Água com Gás São Lourenço 510ml",
          preco: 3.9,
          imagem: "/placeholder.svg?height=120&width=120",
          categoria: "Águas",
          descricao: "Água mineral com gás natural",
        },
      ]
      setBebidas(menuPadrao)
      localStorage.setItem("bebidas", JSON.stringify(menuPadrao))
    }
  }, [])

  // Agrupar bebidas por categoria
  const categorias = bebidas.reduce(
    (acc, bebida) => {
      const categoria = bebida.categoria || "Outros"
      if (!acc[categoria]) {
        acc[categoria] = []
      }
      acc[categoria].push(bebida)
      return acc
    },
    {} as Record<string, Bebida[]>,
  )

  const ordensCategorias = ["Cervejas", "Destilados", "Refrigerantes", "Energéticos", "Vinhos", "Águas", "Outros"]

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button size="icon" variant="outline">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center">
                <span className="text-lg">🍺</span>
              </div>
              <div>
                <h1 className="font-bold text-gray-900">Bar do Léo</h1>
                <p className="text-sm text-gray-600">CARDÁPIO COMPLETO</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Info do Estabelecimento */}
      <div className="bg-gray-50 border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Cardápio Bar do Léo</h2>
            <p className="text-gray-600 mb-4">Depósito de Bebidas - As melhores bebidas com os melhores preços</p>

            <div className="flex items-center justify-center gap-6 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                <span>Entrega: 20-60min</span>
              </div>
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <span>4.6 avaliação</span>
              </div>
              <div className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                <span>Centro - São Paulo</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Menu por Categorias */}
      <div className="container mx-auto px-4 py-8">
        {ordensCategorias.map((nomeCategoria) => {
          const produtosDaCategoria = categorias[nomeCategoria]
          if (!produtosDaCategoria || produtosDaCategoria.length === 0) return null

          return (
            <div key={nomeCategoria} className="mb-12">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">
                    {nomeCategoria === "Cervejas" && "🍺"}
                    {nomeCategoria === "Destilados" && "🥃"}
                    {nomeCategoria === "Refrigerantes" && "🥤"}
                    {nomeCategoria === "Energéticos" && "⚡"}
                    {nomeCategoria === "Vinhos" && "🍷"}
                    {nomeCategoria === "Águas" && "💧"}
                    {nomeCategoria === "Outros" && "📦"}
                  </span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900">{nomeCategoria}</h3>
                <div className="flex-1 h-px bg-gray-200"></div>
              </div>

              <div className="grid gap-4">
                {produtosDaCategoria.map((bebida) => (
                  <Card key={bebida.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        {/* Imagem */}
                        <div className="w-20 h-20 flex-shrink-0">
                          <Image
                            src={bebida.imagem || "/placeholder.svg"}
                            alt={bebida.nome}
                            width={80}
                            height={80}
                            className="w-full h-full object-cover rounded-lg"
                          />
                        </div>

                        {/* Informações */}
                        <div className="flex-1">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h4 className="font-semibold text-lg text-gray-900">{bebida.nome}</h4>
                              {bebida.descricao && <p className="text-gray-600 text-sm mt-1">{bebida.descricao}</p>}
                              {bebida.observacao && (
                                <p className="text-xs text-orange-600 font-medium mt-1 uppercase">
                                  {bebida.observacao}
                                </p>
                              )}
                            </div>

                            <div className="text-right">
                              <div className="flex items-center gap-2">
                                <span className="text-2xl font-bold text-green-600">
                                  R$ {bebida.preco.toFixed(2).replace(".", ",")}
                                </span>
                                {bebida.precoOriginal && (
                                  <div className="text-right">
                                    <p className="text-sm text-gray-500 line-through">
                                      R$ {bebida.precoOriginal.toFixed(2).replace(".", ",")}
                                    </p>
                                    {bebida.desconto && (
                                      <Badge className="bg-red-500 text-xs">-{bebida.desconto}% OFF</Badge>
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )
        })}

        {bebidas.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">Cardápio em construção...</p>
            <p className="text-gray-400">Em breve teremos nosso cardápio completo!</p>
          </div>
        )}
      </div>

      {/* Footer do Menu */}
      <div className="bg-gray-50 border-t">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Faça seu Pedido</h3>
            <p className="text-gray-600 mb-6">Entre em contato conosco para fazer seu pedido ou tire suas dúvidas</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-green-600 hover:bg-green-700">📱 WhatsApp: (11) 99999-9999</Button>
              <Button variant="outline">📞 Telefone: (11) 99999-9999</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
