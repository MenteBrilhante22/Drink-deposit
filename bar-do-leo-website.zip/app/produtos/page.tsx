"use client"

import { useState, useEffect } from "react"
import { Search, ArrowLeft } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"

interface Bebida {
  id: string
  nome: string
  preco: number
  imagem: string
  categoria?: string
  precoOriginal?: number
  desconto?: number
  observacao?: string
}

const categories = [
  { name: "TODOS", active: false },
  { name: "PROMOÇÕES", active: true },
  { name: "Energéticos", active: false },
  { name: "Destilados", active: false },
  { name: "Cervejas", active: false },
  { name: "Refrigerantes", active: false },
]

export default function ProductsPage() {
  const [bebidas, setBebidas] = useState<Bebida[]>([])
  const [activeCategory, setActiveCategory] = useState("TODOS")
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    const bebidasSalvas = localStorage.getItem("bebidas")
    if (bebidasSalvas) {
      setBebidas(JSON.parse(bebidasSalvas))
    }
  }, [])

  const filteredProducts = bebidas.filter((bebida) => {
    const matchesSearch = bebida.nome.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory =
      activeCategory === "TODOS" ||
      (activeCategory === "PROMOÇÕES" && bebida.precoOriginal) ||
      bebida.categoria === activeCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-white">
      {/* Header Simplificado */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button size="icon" variant="outline">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center">
                <span className="text-lg">🍺</span>
              </div>
              <div>
                <h1 className="font-bold text-gray-900">Bar do Léo</h1>
                <p className="text-sm text-gray-600">CATÁLOGO COMPLETO</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filtros */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-col gap-4">
          {/* Busca */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar bebidas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Categorias */}
          <div className="flex gap-1 overflow-x-auto">
            {categories.map((category, index) => (
              <Button
                key={index}
                variant={activeCategory === category.name ? "default" : "outline"}
                size="sm"
                className={`whitespace-nowrap ${
                  activeCategory === category.name
                    ? "bg-red-600 hover:bg-red-700 text-white"
                    : "text-gray-700 hover:bg-gray-100"
                }`}
                onClick={() => setActiveCategory(category.name)}
              >
                {category.name}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Lista de Produtos */}
      <div className="container mx-auto px-4 pb-8">
        <h2 className="text-xl font-bold text-gray-900 mb-4">
          {activeCategory === "TODOS" ? "TODOS OS PRODUTOS" : activeCategory}
        </h2>

        {filteredProducts.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">
              {bebidas.length === 0
                ? "Nenhuma bebida cadastrada ainda."
                : "Nenhuma bebida encontrada com os filtros selecionados."}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            {filteredProducts.map((bebida) => (
              <Card key={bebida.id} className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-3">
                  <div className="flex gap-3">
                    {/* Imagem do Produto */}
                    <div className="w-16 h-16 flex-shrink-0">
                      <Image
                        src={bebida.imagem || "/placeholder.svg"}
                        alt={bebida.nome}
                        width={64}
                        height={64}
                        className="w-full h-full object-cover rounded"
                      />
                    </div>

                    {/* Informações do Produto */}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-sm text-gray-900 mb-1 line-clamp-2">{bebida.nome}</h3>

                      {bebida.observacao && <p className="text-xs text-gray-500 mb-2 uppercase">{bebida.observacao}</p>}

                      <div className="flex items-center gap-2">
                        <span className="font-bold text-lg text-gray-900">
                          R$ {bebida.preco.toFixed(2).replace(".", ",")}
                        </span>

                        {bebida.precoOriginal && (
                          <>
                            <span className="text-sm text-gray-500 line-through">
                              R$ {bebida.precoOriginal.toFixed(2).replace(".", ",")}
                            </span>
                            {bebida.desconto && (
                              <Badge variant="secondary" className="text-xs bg-red-100 text-red-700">
                                -{bebida.desconto}%
                              </Badge>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
